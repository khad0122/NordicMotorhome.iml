package com.example.nordicmotorhome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NordicMotorhomeApplicationTests {

    @Test
    void contextLoads() {
    }

}
